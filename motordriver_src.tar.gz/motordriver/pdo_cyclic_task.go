package motordriver

/*
#cgo CFLAGS: -g -Wall -I/opt/etherlab/include -I/home/pi/gosrc/src/EtherCAT
#cgo LDFLAGS: -L/home/pi/gosrc/src/EtherCAT -L/opt/etherlab/lib/  -lethercatinterface -lethercat
#include "ecrt.h"
#include "ethercatinterface.h"
*/
import "C"

import (
	"EtherCAT/logger"
	"errors"
	"sync"
	"sync/atomic"
	"time"
)



// cia402NextControlword computes the next controlword to reach Operation Enabled.
// This is a conservative CiA-402 state machine handler.
func cia402NextControlword(status uint16, opEnabled *bool) uint16 {
    // Fault?
    if (status & 0x0008) != 0 {
        *opEnabled = false
        return 0x0080 // Fault reset
    }
    // Operation enabled?
    // Common pattern for "Operation enabled": statusword bits (0,1,2,5) == 1 and fault==0
    if (status & 0x006F) == 0x0027 {
        *opEnabled = true
        return 0x000F // Enable operation
    }
    *opEnabled = false

    // Not enabled: walk through sequence
    // Ready to switch on: (status & 0x006F) == 0x0021 (often)
    if (status & 0x006F) == 0x0021 {
        return 0x0007 // Switch on
    }
    // Switched on: (status & 0x006F) == 0x0023
    if (status & 0x006F) == 0x0023 {
        return 0x000F // Enable operation
    }
    // Default: shutdown to reach ready-to-switch-on
    return 0x0006
}

// rampStep moves current towards goal by at most maxStep counts per cycle.
func rampStep(current, goal int32, maxStep int32) int32 {
    if maxStep <= 0 {
        return goal
    }
    delta := goal - current
    if delta > maxStep {
        return current + maxStep
    }
    if delta < -maxStep {
        return current - maxStep
    }
    return goal
}

var (
	// masterIOMutex serializes all EtherCAT master I/O (PDO send/receive and SDO mailbox).
	masterIOMutex sync.Mutex
	pdoStopCh      = make(chan struct{})
	pdoStopOnce    sync.Once
	pdoStartedOnce sync.Once

	// last PDO position value (shared safely)
	lastPDOPos int32
	// last PDO statusword value (shared safely)
	lastPDOStatus atomic.Uint32
	// additional TxPDO values
	lastPDOErr atomic.Uint32 // 0x603F (uint16) stored in low bits
	lastPDOVel int32         // 0x606C (int32)
	lastPDODI  atomic.Uint32 // 0x60FD (uint32)
)

// GetLastPDOPosition returns latest PDO position read by cyclic loop.
func GetLastPDOPosition() int32 {
	return atomic.LoadInt32(&lastPDOPos)
}

// GetLastPDOStatusword returns latest PDO statusword read by cyclic loop.
func GetLastPDOStatusword() uint16 {
	return uint16(lastPDOStatus.Load() & 0xFFFF)
}

func GetLastPDOErrorCode() uint16 {
	return uint16(lastPDOErr.Load() & 0xFFFF)
}

func GetLastPDOVelocityActual() int32 {
	return atomic.LoadInt32(&lastPDOVel)
}

func GetLastPDODigitalInputs() uint32 {
	return lastPDODI.Load()
}

// StopPDOCyclic stops the cyclic task so Ctrl+C shuts down cleanly.
func StopPDOCyclic() {
	pdoStopOnce.Do(func() { close(pdoStopCh) })
}

// StartPDOCyclic starts ONE cyclic loop that owns master_send/receive.
// Cycle period: 10ms (safe on Raspberry Pi).
func StartPDOCyclic(devices []MasterDevice) error {
	if len(devices) == 0 {
		return errors.New("StartPDOCyclic: no devices")
	}

	// we'll use first device for position (extend later for multiple)
	d := &devices[0]

	if !d.PdoReady || d.Domain == nil {
		return errors.New("StartPDOCyclic: PDO not set up (call SetupPDOPosition first)")
	}

	var startErr error

	pdoStartedOnce.Do(func() {
		// Activate master once (required for domain traffic)
		if C.ecrt_master_activate(d.Master) != 0 {
			startErr = errors.New("StartPDOCyclic: ecrt_master_activate failed")
			return
		}

		pd := C.ecrt_domain_data(d.Domain)
		if pd == nil {
			startErr = errors.New("StartPDOCyclic: ecrt_domain_data returned nil")
			return
		}

		d.DomainPD = (*C.uint8_t)(pd)

		go func() {
		//var currentTarget int32
		//var currentTargetInit bool
			logger.Info("[PDO] cyclic task started (10ms)")

			ticker := time.NewTicker(10 * time.Millisecond)
			defer ticker.Stop()

			for {
				select {
				case <-pdoStopCh:
					logger.Info("[PDO] cyclic task stopped")
					return
				case <-ticker.C:
					// ONLY place in your program that should do send/receive for PDO
					masterIOMutex.Lock()
					C.ecrt_master_receive(d.Master)
					C.ecrt_domain_process(d.Domain)

					// ========== Read TxPDO (from drive) ==========

					if d.PdoPosReady {
						pos := C.read_s32((*C.uint8_t)(d.DomainPD), d.OffPos)
						atomic.StoreInt32(&lastPDOPos, int32(pos))
					}

					if d.PdoStatusReady {
						sw := C.read_u16((*C.uint8_t)(d.DomainPD), d.OffStatus)
						lastPDOStatus.Store(uint32(sw))
					}

					if d.PdoErrorReady {
						err := C.read_u16((*C.uint8_t)(d.DomainPD), d.OffErrorCode)
						lastPDOErr.Store(uint32(err))
					}

					if d.PdoVelReady {
						vel := C.read_s32((*C.uint8_t)(d.DomainPD), d.OffVelActual)
						atomic.StoreInt32(&lastPDOVel, int32(vel))
					}

					if d.PdoDIReady {
						di := C.read_u32((*C.uint8_t)(d.DomainPD), d.OffDigitalInputs)
						lastPDODI.Store(uint32(di))
					}

					// ========== Write RxPDO (to drive) ==========

					// Write jogging setpoints (RxPDO) if enabled.
// No SDOs here: we reach "Operation enabled" using statusword + controlword via PDO,
// then apply opmode + target velocity only when enabled.
if d.PdoJogEnabled && d.DomainPD != nil {
    if d.PdoJogReady {
        // Always set requested operation mode (typically 3 = Profile Velocity / CSV)
        op := int8(d.desiredOpMode.Load())
        C.write_s8((*C.uint8_t)(d.DomainPD), d.OffOpMode, C.int8_t(op))

        // Use CiA-402 state machine to enable the drive
        var status uint16
        opEnabled := false
        if d.PdoStatusReady {
            sw := C.read_u16((*C.uint8_t)(d.DomainPD), d.OffStatus)
            status = uint16(sw)
        }
        cw := uint16(0x0006)
        if d.PdoStatusReady {
            cw = cia402NextControlword(status, &opEnabled)
        }
        C.write_u16((*C.uint8_t)(d.DomainPD), d.OffControlWord, C.uint16_t(cw))

        // Only command non-zero velocity once enabled
        vel := int32(0)
        if opEnabled {
            vel = d.desiredTargetVelocity.Load()
        }
        C.write_s32((*C.uint8_t)(d.DomainPD), d.OffTargetVel, C.int32_t(vel))
    }
}

                    // Write target position (RxPDO) if enabled.
					if d.PdoPosEnabled && d.DomainPD != nil {
						// Positioning via CSP (0x6060 = 8) using RxPDO 0x1600 / TxPDO 0x1A00.
						// Always write opmode + controlword while enabled.
						if true { // PdoRxReady not present in MasterDevice; offsets validated by setup

							// Set CSP mode (8)
							C.write_s8((*C.uint8_t)(d.DomainPD), d.OffOpMode, C.int8_t(8))

							// Read status/pos if available
							var status uint16
							var posActual int32
							if d.PdoStatusReady {
								sw := C.read_u16((*C.uint8_t)(d.DomainPD), d.OffStatus)
								status = uint16(sw)
							}
							if d.PdoPosReady {
								p := C.read_s32((*C.uint8_t)(d.DomainPD), d.OffPos)
								posActual = int32(p)
							}

							// State machine to reach operation enabled
							opEnabled := false
							cw := uint16(0x0006)
							if d.PdoStatusReady {
								cw = cia402NextControlword(status, &opEnabled)
							}
							C.write_u16((*C.uint8_t)(d.DomainPD), d.OffControlWord, C.uint16_t(cw))

							// Target position handling:
							// - while not enabled, hold target at actual to avoid jump
							// - once enabled, ramp towards goal
							if d.PdoPosReady {
								if !opEnabled {
									C.write_s32((*C.uint8_t)(d.DomainPD), d.OffTargetPos, C.int32_t(posActual))
									// Use the struct-level atomic to track position
									d.currentTargetPosition.Store(posActual) 
								} else {
									goal := d.desiredTargetPosition.Load()
									current := d.currentTargetPosition.Load()
									
									// Conservative ramp: 200 counts per 10ms cycle
									next := rampStep(current, goal, 200)
									
									C.write_s32((*C.uint8_t)(d.DomainPD), d.OffTargetPos, C.int32_t(next))
									d.currentTargetPosition.Store(next)
								}
							}
						}
					}

					// Queue and send
					C.ecrt_domain_queue(d.Domain)
					C.ecrt_master_send(d.Master)
					masterIOMutex.Unlock()
			}
		}
	}()
})

	if startErr != nil {
		return startErr
	}
	return nil
}
