package motordriver

func readInputSignal(masterDevice MasterDevice) (int, error) {
	// Prefer PDO (0x60FD) when available to avoid slow/fragile SDO polling.
	if masterDevice.PdoDIReady {
		return int(GetLastPDODigitalInputs()), nil
	}

	// Fallback to SDO
	operation, err := GetEtherCATOperation("readinputsignal", masterDevice.Device.AddressConfigName)
	if err != nil {
		return 0, err
	}
	for _, step := range operation.Steps {
		if step.Action == "write" {
			SDODownload(masterDevice.Master, masterDevice.Position, step)
		} else {
			result, err2 := SDOUpload2(masterDevice.Master, masterDevice.Position, step)
			return result, err2
		}
	}
	return 0, nil
}

func readECSSignal(masterDevice MasterDevice) (int, error) {
	// Prefer PDO (0x60FD) when available - ECS is bit 0
	// This avoids slow SDO calls in tight ECS checking loops
	if masterDevice.PdoDIReady {
		return int(GetLastPDODigitalInputs()), nil
	}

	// Fallback to SDO
	operation, err := GetEtherCATOperation("ecs", masterDevice.Device.AddressConfigName)
	if err != nil {
		return 0, err
	}
	for _, step := range operation.Steps {
		if step.Action == "write" {
			SDODownload(masterDevice.Master, masterDevice.Position, step)
		} else {
			result, err2 := SDOUpload2(masterDevice.Master, masterDevice.Position, step)
			return result, err2
		}
	}
	return 0, nil
}

func hardResetInput(masterDevice MasterDevice) (int, error) {
	// Prefer PDO (0x60FD) when available - Hard Reset is bit 5
	if masterDevice.PdoDIReady {
		return int(GetLastPDODigitalInputs()), nil
	}

	// Fallback to SDO
	operation, err := GetEtherCATOperation("hard_reset", masterDevice.Device.AddressConfigName)
	if err != nil {
		return 0, err
	}
	for _, step := range operation.Steps {
		if step.Action == "write" {
			SDODownload(masterDevice.Master, masterDevice.Position, step)
		} else {
			result, err2 := SDOUpload2(masterDevice.Master, masterDevice.Position, step)
			return result, err2
		}
	}
	return 0, nil
}