package motordriver

/**
Functions in this file poll the status of the driver, it can be the position
or warning or errors.
**/
import (
	channels "EtherCAT/channels"
	logger "EtherCAT/logger"
	"EtherCAT/motordriver/statusnotifier"
	notifier "EtherCAT/motordriver/statusnotifier"
	settings "EtherCAT/settings"
	"fmt"
	"time"
)

var stopChan chan bool

//pollDrivePositionStatus polls the current position of the driver
func pollDrivePosition(avilableDevices []MasterDevice) error {
	logger.Debug("starting driver position listener")
	stopChan = make(chan bool)
	for _, device := range avilableDevices {
		go pollDrivePositionProcess(device)
	}
	return nil
}

func stopDriverPolling() {
	stopChan <- true
}

//pollDrivePositionStatusProcess poll the status of each driver and runs as a go subroutine
func pollDrivePositionProcess(device MasterDevice) {
	logger.Info("polling status of driver: ", device.Name)
	operation, _ := GetEtherCATOperation("pollstatus", device.Device.AddressConfigName)

	if len(operation.Steps) <= 0 {
		return
	}
	driverSettings := settings.GetDriverSettings(device.Name)
	step := operation.Steps[0]
	for {
		select {
		default:
			status, _ := DrivePosition(device.Master, device.Position, step)
			//refer tcpserver.js line# 263
			driveStatus := getCurrentDriverStatus(device.Name)
			curPos, posWithErrCorrection := currentPosition(status, device.Device.DriveXRatio, device.Name)
			go checkPotNotLimit(curPos, device, driverSettings, driveStatus)
			pitchError := getPitchError(device.Name, driveStatus.destinationPosition)

			withErrCorr := (posWithErrCorrection - pitchError) + driveStatus.backlash - driveStatus.workOffset
			if withErrCorr >= 359.999 {
				withErrCorr = 0
			}
			notifier.NotifyCurrentPosition(device.Name, withErrCorr)
			currentDriverPosition(device, curPos)
			dir := "CW"
			if driveStatus.direction <= 0 {
				dir = "CCW"
			}
			logger.PrintOnSameLine("Current postion: corrected:", fmt.Sprintf("%.3f", posWithErrCorrection), "actual:", fmt.Sprintf("%.3f", curPos), "pitch err:", fmt.Sprintf("%.3f", pitchError), "backlash", fmt.Sprintf("%.3f", driveStatus.backlash), "workoffset:", fmt.Sprintf("%.3f", driveStatus.workOffset), "dir:", dir)
			time.Sleep(time.Duration(step.Delay) * time.Microsecond)
		case <-stopChan:
			logger.Debug("stopping driver position listener")
			return
		}
	}
}

//checkPotNotLimit checks whether POT or NOT limit reached
func checkPotNotLimit(currentPosition float64, device MasterDevice, driverSettings settings.DriverSettings, driverStatus driverCurrentStatus) (exceeded bool) {
	// pot or not set exit as per the new change NOT will set as -ve value
	// NOT >0 means NOT is not set and pot<=0 means POT is not set
	if driverSettings.NOT >= 0 || driverSettings.POT <= 0 {
		return false
	}

	if driverStatus.potNotExceeded {
		if driverStatus.potExceeded {
			statusnotifier.Alarm("POT Limit Exceeded")
		} else {
			statusnotifier.Alarm("NOT Limit Exceeded")
		}
		return true
	}
	threshold := device.Device.PotNotThreshold

	exceeded = false
	pot := float64(driverSettings.POT)
	not := float64(driverSettings.NOT)
	//not will be a -ve value, subtract from 360 and that will be NOT value
	//for e.g. 360+-10=350
	not = 360 + not
	//running in positive direction
	if driverStatus.direction == 1 && pot > 0 {
		if currentPosition >= (pot-threshold) && currentPosition <= pot+(threshold*10) {
			FastPowerOff(masterDevices[0])
			StopJog(masterDevices[0])
			logger.Trace("pot limit exceeded")
			channels.WriteCommandExecInput("stop_prog_exec", "")
			statusnotifier.Alarm("POT Limit Exceeded")
			exceeded = true
			notifyDriverStatus("pot_not_exceeded", "POT", device)
		}
	}
	//(249.99 <= 250+1.5 && 249.99 >= 250-1.5)  // 249.99 <=251.5 && 249.99>=248.5
	if driverStatus.direction == -1 && not > 0 {
		if currentPosition <= (not+threshold) && currentPosition >= not-(threshold*10) {
			// channels.NotifyMotorDriver("FAST_POWER_OFF", "", driveName, 0)
			FastPowerOff(masterDevices[0])
			StopJog(masterDevices[0])
			logger.Trace("not limit exceeded")
			channels.WriteCommandExecInput("stop_prog_exec", "")
			statusnotifier.Alarm("NOT Limit Exceeded")

			notifyDriverStatus("pot_not_exceeded", "NOT", device)
			exceeded = true
		}
	}
	return
}
