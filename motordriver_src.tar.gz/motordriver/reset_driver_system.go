package motordriver

import (
	channels "EtherCAT/channels"
	"EtherCAT/logger"
	"EtherCAT/motordriver/statusnotifier"
)

/*
function waits for reset from the ui, the reset will stop and start different go routines which listens for different
parameters. Also Reset motor drivers and command execution status. This will set the system back to initial state.
*/

func listenSystemReset() {
	channels.ResetDriverSystem = make(chan bool)
	go resetSystemWorker()
}

func performSysReset(checkMotorRunning bool) {
	if checkMotorRunning {
		for _, dev := range masterDevices {
			stat := getCurrentDriverStatus(dev.Name)
			if stat.isMotorRunning {
				logger.Info("Unable to do system reset, motor", dev.Name, "is running")
				statusnotifier.Alarm("Unable to do system reset, motor " + dev.Name + " is running")
				statusnotifier.SocketMessage("reset_done", "reset completed")
				return
			}
		}
	}
	channels.ResetDriverSystem <- true
}

func resetSystemWorker() {
	for {
		msg := <-channels.ResetDriverSystem
		if msg == true {
			logger.Info("resetting driver system....")
			stopDriverPolling()
			stopDriverActionListener()
			stopDriveStatusListener()
			stopErrorPolling()
			stopPollIOStat()
			stopECSCheck()
			doneDriverAction()
			channels.WriteCommandExecInput("reset", "")
			channels.NotifyCmdComplete()
			ShutdownMasters()

			PowerOnMasters()
			ResetDriver(masterDevices)
			pollDrivePosition(masterDevices)
			pollDriveError(masterDevices)
			pollIOStat(masterDevices)
			initDriverActionListener()
			startDriverStatusListener()
			logger.Info("resetting driver completed....")
			statusnotifier.Alarm("No Alarms")
			statusnotifier.SocketMessage("reset_done", "reset completed")
		}
	}
}

//StopSystem stop all the channel listeners and motor driver.
func StopSystem() {
	if !HasDriverConnected() {
		return
	}
	stopDriverPolling()
	stopDriverActionListener()
	stopDriveStatusListener()
	stopErrorPolling()
	channels.WriteCommandExecInput("reset", "")
	channels.NotifyCmdComplete()
	ShutdownMasters()
}
