package motordriver

/*
#cgo CFLAGS: -g -Wall -I/opt/etherlab/include -I/home/pi/gosrc/src/EtherCAT
#cgo LDFLAGS: -L/home/pi/gosrc/src/EtherCAT -L/opt/etherlab/lib/  -lethercatinterface -lethercat
#include "ecrt.h"
#include "ethercatinterface.h"
#include <string.h>
*/
import "C"

import (
	"errors"
	"fmt"
)

// SetupPDOPosition registers PDO entries into a domain for an EXISTING master.
// Now includes ALL TxPDO entries from 0x1A01 mapping including digital inputs.
// SAFE: does not start cyclic traffic and does not activate master.
func SetupPDOPosition(dev *MasterDevice) error {
	if dev == nil || dev.Master == nil {
		return errors.New("SetupPDOPosition: nil master device")
	}

	// Create domain
	domain := C.ecrt_master_create_domain(dev.Master)
	if domain == nil {
		return errors.New("SetupPDOPosition: failed to create domain")
	}

	// Must get slave config before activation
	sc := C.ecrt_master_slave_config(
		dev.Master,
		C.ushort(dev.Device.Alias),
		C.ushort(dev.Device.ID),
		C.uint(dev.Device.VendorID),
		C.uint(dev.Device.ProductCode),
	)
	if sc == nil {
		return errors.New("SetupPDOPosition: ecrt_master_slave_config failed (alias/position/vendor/product mismatch)")
	}

	// Configure PDO mapping 0x1601/0x1A01 (includes velocity support)
	if rc := C.configure_minas_a6_pdos(sc); rc != 0 {
		return fmt.Errorf("SetupPDOPosition: configure_minas_a6_pdos failed: %v", C.GoString(C.strerror(-rc)))
	}

	// ========== Register TxPDO entries (read from drive) ==========

	// Register 0x6064:0 (Position Actual Value)
	var offPos C.uint
	if C.setup_pos_pdo(
		domain,
		C.ushort(dev.Device.Alias),
		C.ushort(dev.Device.ID),
		C.uint(dev.Device.VendorID),
		C.uint(dev.Device.ProductCode),
		(*C.uint)(&offPos),
	) != 0 {
		return errors.New("SetupPDOPosition: setup_pos_pdo failed (0x6064:0 not mapped in TxPDO)")
	}
	dev.OffPos = offPos
	dev.PdoReady = true

	// Register 0x6041:0 (Statusword)
	var offStatus C.uint
	if C.setup_statusword_pdo(
		domain,
		C.ushort(dev.Device.Alias),
		C.ushort(dev.Device.ID),
		C.uint(dev.Device.VendorID),
		C.uint(dev.Device.ProductCode),
		(*C.uint)(&offStatus),
	) == 0 {
		dev.OffStatus = offStatus
		dev.PdoStatusReady = true
	} else {
		dev.PdoStatusReady = false
	}

	// Register 0x603F:0 (Error code)
	var offError C.uint
	if C.setup_error_code_pdo(
		domain,
		C.ushort(dev.Device.Alias),
		C.ushort(dev.Device.ID),
		C.uint(dev.Device.VendorID),
		C.uint(dev.Device.ProductCode),
		(*C.uint)(&offError),
	) == 0 {
		dev.OffErrorCode = offError
		dev.PdoErrorReady = true
	} else {
		dev.PdoErrorReady = false
	}
	// Register 0x60FD:0 (Digital inputs) - CRITICAL for ECS, POT, NOT, etc.
	var offDI C.uint
	if C.setup_digital_inputs_pdo(
		domain,
		C.ushort(dev.Device.Alias),
		C.ushort(dev.Device.ID),
		C.uint(dev.Device.VendorID),
		C.uint(dev.Device.ProductCode),
		(*C.uint)(&offDI),
	) == 0 {
		dev.OffDigitalInputs = offDI
		dev.PdoDIReady = true
	} else {
		dev.PdoDIReady = false
	}

	// Store domain for cyclic task (DomainPD assigned after activation)
	dev.Domain = domain

	// ========== Register RxPDO entries (write to drive) ==========

	// Try to register RxPDO entries for jogging (0x6040, 0x6060, 0x60FF)
	if offCW, offOp, offVel, jerr := SetupPDOJog(domain, sc, uint32(dev.Device.Alias), uint32(dev.Device.ID), uint32(dev.Device.VendorID), uint32(dev.Device.ProductCode)); jerr == nil {
		dev.OffControlWord = C.uint(offCW)
		dev.OffOpMode = C.uint(offOp)
		dev.OffTargetVel = C.uint(offVel)
		dev.PdoJogReady = true
	} else {
		// Keep TxPDO working even if RxPDO mapping isn't available.
		dev.PdoJogReady = false
		_ = jerr
	}

	// Try to register Target Position RxPDO entry (0x607A)
	if offTargetPos, perr := SetupPDOTargetPosition(domain, uint32(dev.Device.Alias), uint32(dev.Device.ID), uint32(dev.Device.VendorID), uint32(dev.Device.ProductCode)); perr == nil {
		dev.OffTargetPos = C.uint(offTargetPos)
		dev.PdoPosReady = true
	} else {
		dev.PdoPosReady = false
		_ = perr
	}

	return nil
}

// SetupPDOJog registers RxPDO entries required for jogging via PDO.
// It returns offsets for Controlword (0x6040), OpMode (0x6060) and TargetVelocity (0x60FF).
func SetupPDOJog(domain *C.ec_domain_t, slaveConfig *C.ec_slave_config_t, alias, position, vendor, product uint32) (offCW, offOpMode, offTargetVel uint, err error) {
    var cw, op, vel C.uint
    // Register Controlword (0x6040), Modes of operation (0x6060) and Target velocity (0x60FF)
    // NOTE: 0x60FF must be present in the drive's RxPDO mapping (0x1600) – see ethercatinterface.c.
    if ret := C.setup_jog_pdo(domain,
        slaveConfig,
        C.uint(alias),
        C.uint(position),
        C.uint(vendor),
        C.uint(product),
        &cw,
        &op,
        &vel,
    ); ret != 0 {
        return 0, 0, 0, fmt.Errorf("Failed to register Jog RxPDO entries: %v", C.GoString(C.strerror(-ret)))
    }
    return uint(cw), uint(op), uint(vel), nil
}

// SetupPDOTargetPosition registers RxPDO entry for Target Position (0x607A:0).
func SetupPDOTargetPosition(domain *C.ec_domain_t, alias, position, vendor, product uint32) (offTargetPos uint, err error) {
	var offPos C.uint

	if ret := C.setup_target_pos_pdo(domain,
		C.uint(alias),
		C.uint(position),
		C.uint(vendor),
		C.uint(product),
		&offPos,
	); ret != 0 {
		return 0, fmt.Errorf("Failed to register Target Position PDO entry: %v", C.GoString(C.strerror(-ret)))
	}

	return uint(offPos), nil
}