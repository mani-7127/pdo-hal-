package motordriver

import (
	helper "EtherCAT/helper"
	logger "EtherCAT/logger"
	"EtherCAT/motordriver/statusnotifier"
	settings "EtherCAT/settings"
	"errors"
	"fmt"
	"strconv"
)

func reverseDir(masterDevice MasterDevice) error {
	logger.Trace("Reverse direction activated for driver", masterDevice.Name)
	operation, err := GetEtherCATOperation("reverse", masterDevice.Device.AddressConfigName) //ethercatAddress.GetOperation("poweron")
	if err != nil {
		return err
	}
	for _, step := range operation.Steps {
		SDODownload(masterDevice.Master, masterDevice.Position, step)
	}
	return nil
}

func nonReverseDir(masterDevice MasterDevice) error {
	logger.Trace("Non reverse direction activated for driver", masterDevice.Name)
	operation, err := GetEtherCATOperation("nonreverse", masterDevice.Device.AddressConfigName) //ethercatAddress.GetOperation("poweron")
	if err != nil {
		return err
	}
	for _, step := range operation.Steps {
		SDODownload(masterDevice.Master, masterDevice.Position, step)
	}
	return nil
}

//ManualJog start jogging. Direction param can be 1 or -1
//1 will drive the motor in clock wise and -1 in counter clock wise
func ManualJog(masterDevice MasterDevice, direction int) error {
	driverStatus := getCurrentDriverStatus(masterDevice.Device.Name)
	if driverStatus.potNotExceeded {
		logger.Error("pot/not exceeded, exiting from move command")
		return errors.New("pot/not exceeded, exiting from move command")
	}
	logger.Trace("manual jog, driver: ", masterDevice.Name)
	envSettings := settings.GetDriverSettings(masterDevice.Name)
	notifyDriverStatus("set_backlash", fmt.Sprintf("%f", 0.00), masterDevice)
	FastPowerOn(masterDevice) // Pass by value if that's what FastPowerOn expects

	_, declampErr := hasDeclamped(masterDevice, envSettings)
	if declampErr != nil {
		logger.Error(declampErr)
		statusnotifier.Alarm(declampErr.Error())
		return declampErr
	}

	notifyDriverStatus("motor_running", "true", masterDevice)
	operation, err := GetEtherCATOperation("manualjog", masterDevice.Device.AddressConfigName)
	if err != nil {
		return err
	}
	rpm := direction * int(masterDevice.Device.RPMConst*envSettings.JogFeed)
    
	if masterDevice.PdoJogReady {
		// Enable cyclic RxPDO updates for jog while running.
		masterDevice.EnableJogPDO(true)
		logger.Info("[PDO] Jog enabled for driver:", masterDevice.Name)
	}

	for _, step := range operation.Steps {
		if step.Value == "jog_rpm_placeholder" {
			step.Value = strconv.Itoa(rpm)
		}

		if masterDevice.PdoJogReady {
			val, _ := step.GetValue()
			
			switch step.Address {
			case 0x6040: // Controlword
				masterDevice.desiredControlWord.Store(uint32(val))
				continue
			case 0x6060: // Modes of operation
				masterDevice.desiredOpMode.Store(int32(val))
				continue
			case 0x60FF: // Target velocity
				masterDevice.SetTargetVelocityPDO(int32(val)) // Use signed int32!
				continue
			}
		}
		// Only SDO download steps that are NOT in the PDO mapping
		SDODownload(masterDevice.Master, masterDevice.Position, step)
	}
    
	return nil
}

//StopJog stop jogging
func StopJog(masterDevice MasterDevice) error {
	logger.Trace("stop jog, driver: ", masterDevice.Name)
	operation, err := GetEtherCATOperation("stopjog", masterDevice.Device.AddressConfigName)
	if err != nil {
		return err
	}
	for _, step := range operation.Steps {
		// Prefer PDO for jog-related setpoints when available.
		if masterDevice.PdoJogReady {
			val, vErr := step.GetValue()
			if vErr == nil {
				switch step.Address {
				case 0x6040: // Controlword
					_ = masterDevice.SetJogPDOSetpoints(uint16(val), int8(masterDevice.desiredOpMode.Load()), masterDevice.desiredTargetVelocity.Load())
					logger.Trace("[PDO] Stop jog controlword set for driver:", masterDevice.Name)
					continue
				case 0x6060: // Modes of operation
					_ = masterDevice.SetJogPDOSetpoints(uint16(masterDevice.desiredControlWord.Load()&0xFFFF), int8(val), masterDevice.desiredTargetVelocity.Load())
					logger.Trace("[PDO] Stop jog opmode set for driver:", masterDevice.Name)
					continue
				case 0x60FF: // Target velocity
					_ = masterDevice.SetTargetVelocityPDO(int32(val))
					logger.Trace("[PDO] Stop jog target velocity set for driver:", masterDevice.Name)
					continue
				}
			}
		}
		SDODownload(masterDevice.Master, masterDevice.Position, step)
	}
	if masterDevice.PdoJogReady {
		_ = masterDevice.SetTargetVelocityPDO(0)
		masterDevice.EnableJogPDO(false)
		logger.Info("[PDO] Jog disabled for driver:", masterDevice.Name)
	}
	notifyDriverStatus("motor_running", "false", masterDevice)
	envSettings := settings.GetDriverSettings(masterDevice.Name)
	_, clampErr := hasClamped(masterDevice, envSettings)
	if clampErr != nil {
		logger.Error(clampErr)
		statusnotifier.Alarm(clampErr.Error())
		return clampErr
	}
	return nil
}

//hasTargetReached calls the specialized driver module and check whether the
//intented target position reached
func hasTargetReached(masterDevice MasterDevice) error {
	operation, err := GetEtherCATOperation("jog", masterDevice.Device.AddressConfigName)
	if err != nil {
		return err
	}
	driver := GetMotorDriver()
	driver.hasTargetReached(masterDevice, 0, 0, operation)
	return nil
}

//freeRotate will not wait for ECS or will not send fin signal.
func freeRotate(masterDevice MasterDevice, valueinDegree float64) error {
	logger.Trace("freeRotate to postion, driver", masterDevice.Name, "degree:", valueinDegree)
	err := doRotate(masterDevice, valueinDegree)
	if err != nil {
		return err
	}
	doneDriverAction()
	logger.Trace("freeRotate to postion completed, driver", masterDevice.Name)

	return nil
}

//doRotate function which power on and rotate to a degree, it waits for declamping and clamping.
func doRotate(masterDevice MasterDevice, valueinDegree float64) error {
    FastPowerOn(masterDevice)
    envSettings := settings.GetDriverSettings(masterDevice.Name)
    _, declampErr := hasDeclamped(masterDevice, envSettings)
    if declampErr != nil {
        logger.Error(declampErr)
        statusnotifier.Alarm(declampErr.Error())
        return declampErr
    }

    notifyDriverStatus("motor_running", "true", masterDevice)
    operation, err := GetEtherCATOperation("moveToPosition", masterDevice.Device.AddressConfigName)
    if err != nil {
        return err
    }

	pulses := getPulsesFromDegree(masterDevice, helper.RoundFloatTo3(valueinDegree))
	for _, step := range operation.Steps {
		if step.Value == "move_to_pos_val" {
			step.Value = fmt.Sprintf("%d", pulses)
			logger.Trace("move to pos step value", step.Value)
		}

		// Prefer PDO for target position when available.
		if masterDevice.PdoPosReady && step.Address == 0x607A {
			_ = masterDevice.SetTargetPositionPDO(int32(pulses))
			masterDevice.EnablePosPDO(true)
			logger.Info("[PDO] Target position set for driver:", masterDevice.Name, "pulses:", pulses)
			continue
		}

		// Also prefer PDO for Controlword when cyclic task is running.
		// (Rotation trigger / set-point latch should not be an SDO during runtime.)
		if masterDevice.PdoPosReady && step.Address == 0x6040 {
			val, vErr := step.GetValue()
			if vErr == nil {
				// Store the parsed integer value into the atomic Uint32
				masterDevice.desiredControlWord.Store(uint32(val))
			}
			continue
		}

		// --- ADDITION: stop immediately if SDO download fails ---
		sdoErr := SDODownload(masterDevice.Master, masterDevice.Position, step)
		if sdoErr != nil {
			logger.Error("SDODownload failed for driver:", masterDevice.Name,
				"step:", step.Name, "error:", sdoErr)
            statusnotifier.Alarm(fmt.Sprintf("SDO failed for %s, stopping program", masterDevice.Name))
            return fmt.Errorf("SDODownload failed: %v", sdoErr)
        }
        // ---------------------------------------------------------
	}

	hasTargetReached(masterDevice)
	if masterDevice.PdoPosReady {
		masterDevice.EnablePosPDO(false)
		logger.Info("[PDO] Target position disabled for driver:", masterDevice.Name)
	}
    notifyDriverStatus("motor_running", "false", masterDevice)
    _, clampErr := hasClamped(masterDevice, envSettings)
    if clampErr != nil {
        logger.Error(clampErr)
        statusnotifier.Alarm(clampErr.Error())
        return clampErr
    }

    // if isClamped {
    //     FastPowerOff(masterDevice)
    // }
    return nil
}
