// ============================================================================
// COMPLETE a6_minas_motor_driver.go WITH POT/NOT DISABLED FOR TESTING
// ============================================================================
// Replace your existing motordriver/a6_minas_motor_driver.go with this file
// ============================================================================

package motordriver

/**
Specialized implementation of Panasonic A6 Minas motor driver. All the functions in this file is
specifically designed for A6 Minas. In case to run against a different driver then implement the
same functions in another file.
**/
import (
	ethercatDevice "EtherCAT/ethercatdevicedatatypes"
	helper "EtherCAT/helper"
	logger "EtherCAT/logger"
	"EtherCAT/motordriver/statusnotifier"
	"errors"
	"time"
)

//A6Minas implementation for Panasonic A6 Minas driver
type A6Minas struct{}

//hasTargetReached A6 Minas driver specific  function
//Needs specific requirement to check whether it reach the position and cannot write in generic way
func (a6 A6Minas) hasTargetReached(masterDevice MasterDevice, action int, immediate int, operation ethercatDevice.Operation) error {
	logger.Trace("A6Minas rotation started")
	firstStep := operation.Steps[0]
	secondStep := operation.Steps[1]
	SDODownload(masterDevice.Master, masterDevice.Position, firstStep)
	for {
		result, _ := SDOUpload2(masterDevice.Master, masterDevice.Position, secondStep)
		toBinary := helper.IntToBinary(result)
		// logger.Debug("jog status in binary (reversed)", toBinary)
		if toBinary[10] == '1' && toBinary[12] == '0' {
			logger.Trace("A6Minas rotation completed")
			logger.Trace("A6Minas rotation completed")
			return nil
		}
		if toBinary[10] == '1' && toBinary[12] == '1' {
			firstStep.Value = "0x004f"
			logger.Trace("A6Minas rotation completed",firstStep.Value)
			SDODownload(masterDevice.Master, masterDevice.Position, firstStep)
		}
	}
	return nil
}

//Not used
func (a6 A6Minas) potNotEnabled(masterDevice MasterDevice) (bool, error) {
	inputStatus, err := readInputSignal(masterDevice)
	if err != nil {
		return false, err
	}
	logger.Debug("Input signal value to check pot/not status", inputStatus)
	toBinary := helper.IntToBinary(inputStatus)
	if toBinary[0] == '1' || toBinary[1] == '1' {
		return true, nil
	}
	return false, nil
}

//readDeclampSignal reads the declamp status of the driver
func (a6 A6Minas) readDeclampSignal(masterDevice MasterDevice, declampTiming int) (bool, error) {
	logger.Debug("waiting for declamp status")
	start := time.Now()
	for i := 0; i < declampTiming; i++ {
		inputStatus, err := readInputSignal(masterDevice)
		if err != nil {
			break
		}

		toBinary := helper.IntToBinary(inputStatus)
		if toBinary[7] == '1' {
			return true, nil
		}
		elapsed := time.Since(start)
		time.Sleep(time.Microsecond * 1)
		if elapsed.Milliseconds() > int64(declampTiming) {
			break
		}
	}
	statusnotifier.DriverError(65379)
	return false, errors.New("declamp failed")
}

func (a6 A6Minas) readClampSignal(masterDevice MasterDevice, clampTiming int) (bool, error) {
	logger.Debug("waiting for clamp status", clampTiming, "ms")
	start := time.Now()
	for i := 0; i < clampTiming; i++ {
		inputStatus, err := readInputSignal(masterDevice)
		if err != nil {
			break
		}

		toBinary := helper.IntToBinary(inputStatus)
		if toBinary[6] == '1' {
			return true, nil
		}
		elapsed := time.Since(start)
		time.Sleep(time.Microsecond * 1)
		if elapsed.Milliseconds() > int64(clampTiming) {
			break
		}
	}
	statusnotifier.DriverError(65378)
	return false, errors.New("clamp failed")
}

//receivedECS check whether ECS received or not. As per the requirement ECS should be enabled for 2sec
//if ECS is enabled for 2 sec then return ECS received else false.
// Returns
//   1: Received ECS
//   0: Not received ECS
//   2: Exit from ECS check
func (a6 A6Minas) receivedECS(masterDevice MasterDevice, operation ethercatDevice.Operation, stopECSChan chan bool) int {
	for {
		select {
		default:
			inputStatus, err := readECSSignal(masterDevice)
			if err != nil {
				continue
			}
			toBinary := helper.IntToBinary(inputStatus)

			//&& i == 2000
			if toBinary[0] == '1' {
				return 1
			}
			time.Sleep(time.Duration(10) * time.Microsecond)
		case <-stopECSChan:
			logger.Debug("stopping ECS Polling")
			return 2
		}
	}
}

func (a6 A6Minas) receivedECSZero(masterDevice MasterDevice, operation ethercatDevice.Operation, stopECSChan chan bool) int {
	for {
		select {
		default:
			inputStatus, err := readECSSignal(masterDevice)
			if err != nil {
				continue
			}
			toBinary := helper.IntToBinary(inputStatus)

			//&& i == 2000
			if toBinary[0] == '0' {
				return 1
			}
			time.Sleep(time.Duration(10) * time.Microsecond)
		case <-stopECSChan:
			logger.Debug("stopping ECS zero Polling")
			return 2
		}
	}
}

func (a6 A6Minas) sendFinishSignal(masterDevice MasterDevice, operation ethercatDevice.Operation) error {
	return nil
}

var stopIOStatChan chan bool

func (a6 A6Minas) pollIOStat(avilableDevices []MasterDevice) {
	logger.Debug("starting A6Minas io status listener")
	stopIOStatChan = make(chan bool)
	for _, d := range avilableDevices {
		go a6.ioStatusListener(d)
	}
}

func (a6 A6Minas) stopPollIOStat() {
	stopIOStatChan <- true
}

func (a6 A6Minas) ioStatusListener(masterDev MasterDevice) {

	for {
		select {
		default:
			var ioStat statusnotifier.IOStatus
			
			// OPTIMIZED: Read digital inputs ONCE (prefers PDO automatically)
			// All I/O signals come from the same register (0x60FD)
			inputStatus, err := readInputSignal(masterDev)
			if err != nil {
				logger.Error("error reading io inputsignals:", err)
				time.Sleep(time.Duration(1000) * time.Microsecond)
				continue
			}
			
			toBinary := helper.IntToBinary(inputStatus)
			
			// DEBUG: Uncomment to see raw values
			// logger.Debug("Digital Inputs RAW:", inputStatus, "Binary:", toBinary)
			
			// Parse all I/O bits from the single read
			ioStat.ECS = a6.isIOOn(toBinary, 0, '1')     // Bit 0
			ioStat.POT = a6.isIOOn(toBinary, 1, '0')     // Bit 1
			ioStat.NOT = a6.isIOOn(toBinary, 2, '0')     // Bit 2
			ioStat.HOME = a6.isIOOn(toBinary, 3, '0')    // Bit 3
			ioStat.ALMIN = a6.isIOOn(toBinary, 4, '0')   // Bit 4
			ioStat.CL = a6.isIOOn(toBinary, 6, '1')      // Bit 6
			ioStat.DCL = a6.isIOOn(toBinary, 7, '1')     // Bit 7
			
			// Check hard reset (bit 5) from same data
			if a6.isIOOn(toBinary, 5, '1') {
				logger.Info("io status listener received hard reset input and performing system reset.")
				go performSysReset(true)
			}
			
			// Driver state-dependent I/O
			driverState := getCurrentDriverStatus(masterDev.Name)
			if driverState.isSendingFinSignal {
				ioStat.FIN = true
			} else {
				ioStat.FIN = false
			}
			if !driverState.isDriverOnOff {
				ioStat.SOLOP = false
			} else {
				ioStat.SOLOP = true
			}
			statusnotifier.NotifyIOStatus(ioStat)

			// ================================================================
			// POT/NOT HARDWARE EMERGENCY STOP - DISABLED FOR TESTING
			// ================================================================
			// UNCOMMENT THE BLOCK BELOW TO RE-ENABLE POT/NOT SAFETY:
			/*
			if masterDev.Device.StopWhenHWPOTNOT {
				if ioStat.NOT {
					statusnotifier.Alarm("NOT Limit Exceeded")
					logger.Error("hardware NOT activated")
					FastPowerOff(masterDev)
					StopJog(masterDev)
				}
				if ioStat.POT {
					statusnotifier.Alarm("POT Limit Exceeded")
					logger.Error("hardware POT activated")
					FastPowerOff(masterDev)
					StopJog(masterDev)
				}
			}
			*/
			// ================================================================
			// NOTE: POT/NOT checking is DISABLED above for testing PDO
			// Software limits in checkPotNotLimit() still work!
			// ================================================================
			
			interval := 1000
			if masterDev.Device.IOPollingInterval > 0 {
				interval = masterDev.Device.IOPollingInterval
			}
			time.Sleep(time.Duration(interval) * time.Microsecond)
			
		case <-stopIOStatChan:
			logger.Debug("stopping A6Minas io status listener")
			return
		}
	}
}

func (a6 A6Minas) isIOOn(binary string, binpos int, isVal rune) bool {
	if len(binary) <= 0 {
		return false
	}

	if binary[binpos] == byte(isVal) {
		return true
	}
	return false
}