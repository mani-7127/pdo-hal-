package motordriver

/**
Functions in this file poll the error status of the driver
**/
import (
	logger "EtherCAT/logger"
	"EtherCAT/motordriver/statusnotifier"
	"errors"
	"time"
)

var stopErrPollingChan chan bool

//pollDriveError polls the errors from the driver
func pollDriveError(avilableDevices []MasterDevice) error {
	logger.Debug("starting driver error listener")
	if len(avilableDevices) <= 0 {
		return errors.New("no driver found")
	}
	stopErrPollingChan = make(chan bool)
	for _, device := range avilableDevices {
		go pollDriveErrWorker(device)
	}
	return nil
}

func stopErrorPolling() {
	stopErrPollingChan <- true
}

//pollDrivePositionStatusProcess poll the error status of each driver and runs as a go subroutine
func pollDriveErrWorker(device MasterDevice) {
	logger.Info("polling error of driver: ", device.Name)
	operation, _ := GetEtherCATOperation("readError", device.Device.AddressConfigName)

	if len(operation.Steps) <= 0 {
		return
	}

	step := operation.Steps[0]
	for {
		select {
		default:
			errCode, _ := SDOUpload2(device.Master, device.Position, step)
			statusnotifier.DriverError(errCode)

			// Notify the error status to motor driver status keeper and if there is any error then only allow reset.
			// when resetting reset this flag to false

			time.Sleep(time.Duration(100000) * time.Microsecond)
		case <-stopErrPollingChan:
			logger.Debug("stopping driver error listener")
			return
		}
	}
}
