package motordriver

import (
	parser "EtherCAT/configparser"
	ethercatDevice "EtherCAT/ethercatdevicedatatypes"
	"EtherCAT/logger"
	"EtherCAT/motordriver/statusnotifier"
	settings "EtherCAT/settings"
	"time"
)

var driverConnectionStatus = "SUCCESS"
var masterDevices []MasterDevice
var ethercatAddressMapping map[string]ethercatDevice.Ethercat

//InitMaster init all master drivers and poweron the drivers.
func InitMaster() error {
	ethercatAddressMapping = make(map[string]ethercatDevice.Ethercat)
	position := 0

	devices, err := parser.ParseDeviceConfig()
	if err != nil {
		return err
	}

	//parse the device specific address mapping file and push to map
	for _, dev := range devices.Device {
		address, parseErr := parser.ParseEthercatAddressConfig(dev.AddressConfigFile)
		if parseErr != nil {
			return parseErr
		}
		ethercatAddressMapping[dev.AddressConfigName] = address
	}

	for _, i := range devices.Device {
		master0, err := RequestMaster(i)
		if err != nil {
			logger.Error(err)
			continue
		}
		if master0 != nil {
			masterDevice := MasterDevice{
				Master:   master0,
				Position: position,
				Name:     i.Name,
				Device:   i,
			}
			masterDevices = append(masterDevices, masterDevice)
			configErr := configureDriver(masterDevice)
			if configErr != nil {
				driverConnectionStatus = "ERROR"
				statusnotifier.DriverStatus(i.Name, "0")
				return configErr
			}
			settings := settings.GetDriverSettings(masterDevice.Name)
			// change the polarity of the driver.
			if settings.MotorDirection == 1 {
				nonReverseDir(masterDevice)
			} else {
				reverseDir(masterDevice)
			}
			statusnotifier.DriverStatus(i.Name, "1")
			time.Sleep(time.Duration(500000) * time.Microsecond)
			PowerOn(masterDevice)
			time.Sleep(time.Duration(500000) * time.Microsecond)

			position++
		}
	}

	setupDrivers(masterDevices)
	initListeners(masterDevices)

	time.Sleep(500 * time.Millisecond)
	if len(masterDevices) > 0 {
		driverConnectionStatus = "SUCCESS"
	}
	return nil
}

func setupDrivers(masterDevices []MasterDevice) {
	for _, dev := range masterDevices {
		settings := settings.GetDriverSettings(dev.Name)
		// if cl/dl is enabled then poweroff the drive and cause the breaks to engage
		// if not enabled then poweron the drive and drive will hold the position.
		if settings.ClampDeclamp == 1 {
			FastPowerOff(dev)
		} else {
			FastPowerOn(dev)
		}
	}
}

func initListeners(masterDevices []MasterDevice) {
	if len(masterDevices) <= 0 {
		return
	}
	initDriverActionListener()
	initDriverStatusKeeperListener()
	listenSystemReset()
	pdoOK := false
	if len(masterDevices) > 0 {
		// Set up PDO registration (safe)
		if err := SetupPDOPosition(&masterDevices[0]); err != nil {
			logger.Warn("PDO setup failed, falling back to SDO polling:", err)
		} else if !masterDevices[0].PdoReady {
			logger.Warn("PDO position not ready (0x6064 not mapped); falling back to SDO polling")
		} else if err := StartPDOCyclic(masterDevices); err != nil {
			logger.Warn("PDO cyclic start failed, falling back to SDO polling:", err)
		} else {
			pdoOK = true
		}
	}
	if pdoOK {
		pollDrivePositionPDO(masterDevices)
	} else {
		// Fallback: use SDO polling for position when PDO is not available.
		pollDrivePosition(masterDevices)
	}
	pollDriveError(masterDevices)
	pollIOStat(masterDevices)
}

//ShutdownMasters poweroff all the master devices
func ShutdownMasters() {
	for _, device := range masterDevices {
		FastPowerOff(device)
	}
}

//PowerOnMasters Poweron available masters
func PowerOnMasters() {
	for _, device := range masterDevices {
		PowerOn(device)
	}
}

//GetEtherCATOperation returns the operation configured in ethercat-device-addressing.yml
func GetEtherCATOperation(operation string, deviceAddressConfigName string) (ethercatDevice.Operation, error) {
	addressMapping := getEtherCATAddress(deviceAddressConfigName)
	return addressMapping.GetOperation(operation)
}

//HasDriverConnected return true/false, false indicates connection to driver is errored
func HasDriverConnected() bool {
	if driverConnectionStatus == "SUCCESS" {
		return true
	}
	return false
}

func getMasterDevices() []MasterDevice {
	return masterDevices
}

//GetEtherCATAddress returns the global structure that holds the address specification of
//Ethercat device
func getEtherCATAddress(deviceAddressConfigName string) ethercatDevice.Ethercat {
	addressMapping := ethercatAddressMapping[deviceAddressConfigName]
	return addressMapping
}
