package motordriver

import (
	"time"

	"github.com/sirupsen/logrus"
)

// pollDrivePositionPDO keeps lastPDOPos visible to the rest of the system without spamming stdout.
// It relies on the PDO cyclic task updating lastPDOPos.
// SAFE: does not touch EtherCAT send/receive.
func pollDrivePositionPDO(_ []MasterDevice) {
	go func() {
		var lastLogged int32
		var lastLogTime time.Time

		ticker := time.NewTicker(200 * time.Millisecond)
		defer ticker.Stop()

		for range ticker.C {
			pos := GetLastPDOPosition()
			now := time.Now()

			// Optional: trace log only when it changes, and at most once per second.
			if pos != lastLogged && now.Sub(lastLogTime) > time.Second {
				logrus.Tracef("[PDO] Position (0x6064): %d", pos)
				lastLogged = pos
				lastLogTime = now
			}
		}
	}()
}
