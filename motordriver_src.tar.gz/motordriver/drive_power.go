package motordriver

import (
	"EtherCAT/ethercatdevicedatatypes"
	logger "EtherCAT/logger"
)

//PowerOn Master device
//0x6040 accepts certain level of control words. For more check page# 83 of SX-DSV03242_R2_1E_A6.pdf
//errorCode = ecrt_master_sdo_upload(master0, 0, 0x6040,0x00, (unsigned char *)&value, sizeof(value), &resultSize, &abortCode);
//Should use the code as above, means the value should convert to unsinged char *
//more about the details here https://www.geeksforgeeks.org/unsigned-char-in-c-with-examples/#:~:text=unsigned%20char%20is%20a%20character,ranges%20from%200%20to%20255.
//here is the codepad which converts an int to bits
func PowerOn(masterDevice MasterDevice) error {
	logger.Trace("poweron driver: ", masterDevice.Name)
	operation, err := GetEtherCATOperation("poweron", masterDevice.Device.AddressConfigName) //ethercatAddress.GetOperation("poweron")
	if err != nil {
		return err
	}
	for _, step := range operation.Steps {
		SDODownload(masterDevice.Master, masterDevice.Position, step)
	}
	return nil
}

//FastPowerOn power on the driver faster. All code will use this function, PowerOn function only used when starting
//the application.
func FastPowerOn(masterDevice MasterDevice) error {
	logger.Trace("fast poweron driver: ", masterDevice.Name)
	operation, err := GetEtherCATOperation("fastPowerOn", masterDevice.Device.AddressConfigName) //ethercatAddress.GetOperation("fastPowerOn")
	if err != nil {
		return err
	}

	for _, step := range operation.Steps {
		err := SDODownload(masterDevice.Master, masterDevice.Position, step)
		if err != nil {
			logger.Error(err)
		}
	}

	notifyDriverStatus("driver_on_off", "1", masterDevice)
	return nil
}

func PowerOffAll(masterDevices []MasterDevice) error {
	for _, d := range masterDevices {
		err := PowerOff(d)
		if err != nil {
			return err
		}
	}
	return nil
}

var powerOff = ethercatdevicedatatypes.Operation{}

//PowerOff the passed driver
func PowerOff(masterDevice MasterDevice) error {
	logger.Trace("poweroff driver: ", masterDevice.Name)
	if powerOff.Name == "" {
		powerOffTmp, err := GetEtherCATOperation("poweroff", masterDevice.Device.AddressConfigName)

		if err != nil {
			return err
		}
		powerOff = powerOffTmp
	}
	for _, step := range powerOff.Steps {
		SDODownload(masterDevice.Master, masterDevice.Position, step)
	}
	notifyDriverStatus("driver_on_off", "0", masterDevice)
	notifyDriverStatus("motor_running", "false", masterDevice)
	return nil
}

//FastPowerOff the passed driver
func FastPowerOff(masterDevice MasterDevice) error {
	logger.Trace("fast poweroff driver: ", masterDevice.Name)
	operation, err := GetEtherCATOperation("fastPowerOff", masterDevice.Device.AddressConfigName)
	if err != nil {
		return err
	}

	for _, step := range operation.Steps {
		// SDODownload(masterDevice.Master, masterDevice.Position, step)
		if step.Action == "read" {
			val, _ := SDOUpload2(masterDevice.Master, masterDevice.Position, step)
			logger.Trace("fast power off current val", val)
		} else {
			err := SDODownload(masterDevice.Master, masterDevice.Position, step)
			if err != nil {
				logger.Error(err)
			}
		}
	}

	notifyDriverStatus("driver_on_off", "0", masterDevice)
	notifyDriverStatus("motor_running", "false", masterDevice)
	return nil
}

func emergency(masterDevice MasterDevice) error {
	logger.Trace("emergency activated ", masterDevice.Name)
	operation, err := GetEtherCATOperation("emergency", masterDevice.Device.AddressConfigName) //ethercatAddress.GetOperation("poweron")
	if err != nil {
		return err
	}
	for _, step := range operation.Steps {
		SDODownload(masterDevice.Master, masterDevice.Position, step)
	}
	return nil
}
