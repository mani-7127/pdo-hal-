package motordriver

/*
#cgo CFLAGS:  -I/home/pi/gosrc/src/EtherCAT -I/opt/etherlab/include
#cgo LDFLAGS: /home/pi/gosrc/src/EtherCAT/libethercatinterface.so -L/opt/etherlab/lib -lethercat -ldl -lpthread
#include <stdlib.h>
#include <string.h>   // <-- ADD THIS
#include "ethercatinterface.h"
*/
import "C"
import (
	"sync/atomic"
	ethercatDevice "EtherCAT/ethercatdevicedatatypes"
	"EtherCAT/logger"
	"EtherCAT/motordriver/statusnotifier"
	"errors"
	"fmt"
	"time"
	"unsafe"
)

//MasterDevice holds all the master devices. For more check etherCatGateway.go
type MasterDevice struct {
	Master *C.ec_master_t

	// --- PDO wiring (safe additions) ---
	Domain   *C.ec_domain_t
	DomainPD *C.uint8_t

	// TxPDO (read)
	OffPos   C.uint
	OffStatus C.uint

	// Additional TxPDO (read) entries for UI table
	OffErrorCode     C.uint // 0x603F:00
	OffVelActual     C.uint // 0x606C:00
	OffDigitalInputs C.uint // 0x60FD:00

	// RxPDO (write) - used for jogging via PDO
	OffControlWord C.uint
	OffOpMode      C.uint
	OffTargetVel   C.uint
	OffTargetPos   C.uint

	PdoReady    bool // TxPDO ready
	PdoJogReady bool // RxPDO ready
	PdoJogEnabled bool
	PdoPosReady  bool // Target position RxPDO ready
	PdoPosEnabled bool
	PdoStatusReady bool // Statusword TxPDO ready
	PdoErrorReady  bool // Error code TxPDO ready
	PdoVelReady    bool // Velocity actual TxPDO ready
	PdoDIReady     bool // Digital inputs TxPDO ready
	PdoRxReady     bool // ADDED: Required by pdo_cyclic_task.go

	// Desired RxPDO values (written each cycle when PdoJogEnabled=true)
	desiredTargetVelocity atomic.Int32
	desiredControlWord    atomic.Uint32 // store U16 in low bits
	desiredOpMode         atomic.Int32  // store S8
	desiredTargetPosition atomic.Int32
	currentTargetPosition atomic.Int32 // ADDED: Required by pdo_cyclic_task.go

	Position int
	Name     string
	Device   ethercatDevice.Device
}

//RequestMaster tries to check master exist
func RequestMaster(device ethercatDevice.Device) (*C.ec_master_t, error) {
	master0 := C.ecrt_request_master(C.uint(device.ID))
	if master0 == nil {
		return nil, errors.New("unable to find master ")
	}
	if master0 != nil {
		domain := C.ecrt_master_create_domain(master0)
		if domain == nil {
			logger.Error("domain is nil")
			return nil, errors.New("unable to create domain")
		}
		epos3 := C.ecrt_master_slave_config(master0, C.ushort(device.ID), C.ushort(device.Alias), C.uint(device.VendorID), C.uint(device.ProductCode))
		if epos3 == nil {
			logger.Error("failed to get slave config")
			return nil, errors.New("failed to get slave config")
		}
	}
	return master0, nil
}

//SDODownload will do ecrt_master_sdo_download operation. Writes the value to the driver.
func SDODownload(master *C.ec_master_t, position int, step ethercatDevice.Step) error {
	var uploadErr error

	valueToWrite, errValue := step.GetValue()
	if errValue != nil {
		return errValue
	}
	abortCode := 0
	dataSize := getSize(step)
	logger.Trace("ethercatGateway->", step.Name, "Addr:", fmt.Sprintf("%X", step.Address), "Indx:", fmt.Sprintf("%X", step.SubIndex), "Val:", valueToWrite, step.DataType)
	for retry := 0; retry < 5; retry++ {
		result := C.sdo_download(master, (C.uint16_t)(position), (C.uint16_t)(step.Address), (C.uint8_t)(step.SubIndex), (*C.uint8_t)(unsafe.Pointer(&valueToWrite)), dataSize, (*C.uint32_t)(unsafe.Pointer(&abortCode)))
		if result >= 0 {
			uploadErr = nil
			break
		} else {
			uploadErr = errors.New("error sending command to driver, step " + step.Name)
			time.Sleep(time.Duration(2) * time.Millisecond)
			logger.Info("retry sending command", step.Name, "retrial count", retry)
		}
	}
	if step.Delay > 0 {
		time.Sleep(time.Duration(step.Delay) * time.Microsecond)
	}
	if uploadErr != nil {
		logger.Error(uploadErr)
		statusnotifier.Alarm("Error sending command to driver, step " + step.Name)
	}
	return uploadErr
}

//SDOUpload will do ecrt_master_sdo_upload operation
func SDOUpload(master *C.ec_master_t, position int, step ethercatDevice.Step) (int32, error) {
	abortCode := 0
	// IMPORTANT: We must read into a correctly-sized buffer.
	// The old code always used uint8_t which breaks U16/U32/I32 reads.
	var toReturn int32
	switch step.DataType {
	case "U32":
		var v C.uint32_t
		ret := C.sdo_upload(master, (C.uint16_t)(position), (C.uint16_t)(step.Address), (C.uint8_t)(step.SubIndex), (*C.uint8_t)(unsafe.Pointer(&v)), C.uint32Size(), (*C.uint32_t)(unsafe.Pointer(&abortCode)))
		if ret < 0 {
			return 0, errors.New("Failed to execute SDO upload: " + C.GoString(C.strerror(-ret)))
		}
		toReturn = int32(v)
	case "U16":
		var v C.uint16_t
		ret := C.sdo_upload(master, (C.uint16_t)(position), (C.uint16_t)(step.Address), (C.uint8_t)(step.SubIndex), (*C.uint8_t)(unsafe.Pointer(&v)), C.uint16Size(), (*C.uint32_t)(unsafe.Pointer(&abortCode)))
		if ret < 0 {
			return 0, errors.New("Failed to execute SDO upload: " + C.GoString(C.strerror(-ret)))
		}
		toReturn = int32(v)
	case "I32":
		var v C.int32_t
		ret := C.sdo_upload(master, (C.uint16_t)(position), (C.uint16_t)(step.Address), (C.uint8_t)(step.SubIndex), (*C.uint8_t)(unsafe.Pointer(&v)), C.int32Size(), (*C.uint32_t)(unsafe.Pointer(&abortCode)))
		if ret < 0 {
			return 0, errors.New("Failed to execute SDO upload: " + C.GoString(C.strerror(-ret)))
		}
		toReturn = int32(v)
	case "I16":
		var v C.int16_t
		ret := C.sdo_upload(master, (C.uint16_t)(position), (C.uint16_t)(step.Address), (C.uint8_t)(step.SubIndex), (*C.uint8_t)(unsafe.Pointer(&v)), C.int16Size(), (*C.uint32_t)(unsafe.Pointer(&abortCode)))
		if ret < 0 {
			return 0, errors.New("Failed to execute SDO upload: " + C.GoString(C.strerror(-ret)))
		}
		toReturn = int32(v)
	default: // U8 / I8 / UINT fallback
		var v C.uint8_t
		ret := C.sdo_upload(master, (C.uint16_t)(position), (C.uint16_t)(step.Address), (C.uint8_t)(step.SubIndex), (*C.uint8_t)(unsafe.Pointer(&v)), C.uint8Size(), (*C.uint32_t)(unsafe.Pointer(&abortCode)))
		if ret < 0 {
			return 0, errors.New("Failed to execute SDO upload: " + C.GoString(C.strerror(-ret)))
		}
		toReturn = int32(v)
	}
	if step.Delay > 0 {
		time.Sleep(time.Duration(step.Delay) * time.Microsecond)
	}
	return toReturn, nil
}

//DrivePosition returns the position of the dive
func DrivePosition(master *C.ec_master_t, position int, step ethercatDevice.Step) (int32, error) {
	valueToWrite, errValue := step.GetValue()
	if errValue != nil {
		return 0, errValue
	}
	toPass := C.uint8_t(valueToWrite)
	pos := C.drivePosition(master, (C.uint16_t)(position), (C.uint16_t)(step.Address), (C.uint8_t)(step.SubIndex), (C.uint8_t)(toPass))

	return int32(pos), nil
}

//SDOUpload2 new version of sdo_upload, this function reads the value from the driver
func SDOUpload2(master *C.ec_master_t, position int, step ethercatDevice.Step) (int, error) {
    v, err := SDOUpload(master, position, step)
    if err != nil {
        return 0, err
    }
    if step.Delay > 0 {
        time.Sleep(time.Duration(step.Delay) * time.Microsecond)
    }
    return int(v), nil
}

func getSize(step ethercatDevice.Step) C.size_t {
	dataSize := C.uint8Size()
	if step.DataType == "U32" {
		dataSize = C.uint32Size()
	} else if step.DataType == "U8" {
		dataSize = C.uint8Size()
	} else if step.DataType == "U16" {
		dataSize = C.uint16Size()
	} else if step.DataType == "UINT" {
		dataSize = C.unintSize()
	} else if step.DataType == "I16" {
		dataSize = C.int16Size()
	} else if step.DataType == "I32" {
		dataSize = C.int32Size()
	} else if step.DataType == "I8" {
		dataSize = C.int8Size()
	} else {
		dataSize = C.uint8Size()
	}

	return dataSize
}


// EnableJogPDO turns on cyclic RxPDO writes for jogging.
// You should call this after PDO has been configured (PdoJogReady=true).
func (d *MasterDevice) EnableJogPDO(enabled bool) {
	d.PdoJogEnabled = enabled
}

// SetJogPDOSetpoints updates the desired RxPDO values that will be written in the PDO cyclic task.
// This does NOT perform any SDO writes; it only updates PDO outputs.
func (d *MasterDevice) SetJogPDOSetpoints(controlWord uint16, opMode int8, targetVelocity int32) error {
	if !d.PdoJogReady {
		return fmt.Errorf("PDO jog outputs are not configured (PdoJogReady=false)")
	}
	d.desiredControlWord.Store(uint32(controlWord))
	d.desiredOpMode.Store(int32(opMode))
	d.desiredTargetVelocity.Store(targetVelocity)
	return nil
}

// Convenience: only update target velocity (keeps last CW/mode).
func (d *MasterDevice) SetTargetVelocityPDO(targetVelocity int32) error {
	if !d.PdoJogReady {
		return fmt.Errorf("PDO jog outputs are not configured")
	}
	// Use atomic store for signed int32
	d.desiredTargetVelocity.Store(targetVelocity) 
	return nil
}

// EnablePosPDO turns on cyclic RxPDO writes for target position.
// Call this after PDO has been configured (PdoPosReady=true).
func (d *MasterDevice) EnablePosPDO(enabled bool) {
	d.PdoPosEnabled = enabled
}

// SetTargetPositionPDO updates the desired Target Position (0x607A) for RxPDO.
func (d *MasterDevice) SetTargetPositionPDO(targetPosition int32) error {
	if !d.PdoPosReady {
		return fmt.Errorf("PDO target position is not configured (PdoPosReady=false)")
	}
	d.desiredTargetPosition.Store(targetPosition)
	return nil
}
