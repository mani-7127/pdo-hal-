package motordriver

import (
	logger "EtherCAT/logger"
)

//ResetDriver reset the motor driver
func ResetDriver(avilableDevices []MasterDevice) error {

	for _, device := range avilableDevices {
		operation, _ := GetEtherCATOperation("faultReset", device.Device.AddressConfigName)
		logger.Info("reset driver: ", device.Name)
		for _, step := range operation.Steps {
			if step.Action == "read" {
				val, _ := SDOUpload2(device.Master, device.Position, step)
				logger.Debug("val", val)
			} else {
				SDODownload(device.Master, device.Position, step)
			}
		}
	}
	return nil
}

//resetMultiTurn reset the multi turn data
func resetMultiTurn(avilableDevices []MasterDevice) error {
	for _, device := range avilableDevices {
		operation, _ := GetEtherCATOperation("resetMultiTurn", device.Device.AddressConfigName)
		logger.Info("reset multi turn: ", device.Name)
		for _, step := range operation.Steps {
			if step.Action == "read" {
				val, _ := SDOUpload2(device.Master, device.Position, step)
				logger.Debug("val", val)
			} else {
				SDODownload(device.Master, device.Position, step)
			}
		}
	}
	return nil
}
