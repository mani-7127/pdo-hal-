package motordriver

import (
	channels "EtherCAT/channels"
	logger "EtherCAT/logger"
	notifier "EtherCAT/motordriver/statusnotifier"
	settings "EtherCAT/settings"
	"fmt"
	"math"
)

//Move the motor to zero position.
func moveToZero(device MasterDevice) error {
	//tcpserver.js line# 842
	logger.Debug("move to zero started")
	driverStatus := getCurrentDriverStatus(device.Device.Name)
	settings := settings.GetDriverSettings(device.Device.Name)
	_ = settings
	var targetPosition = 0.0 //float64(-360)
	notifyDriverStatus("set_backlash", fmt.Sprintf("%f", 0.00), device)
	notifier.NotifyDestinationPosition(device.Name, float32(targetPosition))
	notifyDriverStatus("destination_position", fmt.Sprintf("%f", targetPosition), device)
	// Always choose the shortest path for zero reference.
	position, _ := getAbsolutePosition(driverStatus.currentPosition, 0, true)
	logger.Debug("zero ref position: ", position)
	// Avoid runtime SDO configuration if PDO cyclic task is already running.
	// We only need PP mode + target position, both supported via PDO.
	if !device.PdoReady {
		configureDriver(device)
	} else {
		device.PdoJogEnabled = false
		device.desiredOpMode.Store(int32(1))
	}
	freeRotate(device, position)
	channels.DestinationReached()
	notifier.SocketMessage("gotozero_done", "goto zero completed")
	sendECSFinSignal(device)
	return nil
}

func getPos(currentPos float64, targetPos float64, clockwise bool) float64 {
	currentPos = math.Mod(currentPos, 360)
	modeDiff := math.Mod((currentPos - targetPos), 360)

	if clockwise {
		tomove := math.Mod((360 - modeDiff), 360)
		return tomove
	}

	return math.Mod((modeDiff * -1), 360)
}
