package motordriver

import (
    channels "EtherCAT/channels"
    logger "EtherCAT/logger"
    notifier "EtherCAT/motordriver/statusnotifier"
    "errors"
    "fmt"
    "math"
    "time"

    "github.com/google/uuid"
)

// ----------------------------------------------------------
// 🎯 Precision configuration
// ----------------------------------------------------------
const (
    positionToleranceFastPath = 0.02
    positionToleranceFinal    = 0.02
)

// ----------------------------------------------------------
// 🧩 Helper utility
// ----------------------------------------------------------

func clearTargetReached(device MasterDevice) {
    logger.Debug("Clearing 'target reached' status for device:", device.Name)
}

func sleepMs(ms int) {
    time.Sleep(time.Duration(ms) * time.Millisecond)
}

// ----------------------------------------------------------
// 🚥 Main Motion Function
// ----------------------------------------------------------

func moveMotorToDegree(device MasterDevice, degreeToRotate float64) error {
    driverStatus := getCurrentDriverStatus(device.Device.Name)

    if driverStatus.potNotExceeded {
        logger.Error("pot/not exceeded, exiting from move command")
        return errors.New("pot/not exceeded, exiting from move command")
    }

    uid := uuid.New()
    logger.Info(
        "rotate motor to", degreeToRotate,
        "current:", driverStatus.currentPosition,
        "prev dest:", driverStatus.destinationPosition,
        "workoffset", driverStatus.workOffset,
        "id:", uid,
    )

    var moveToPos, destination float64

    // --- Absolute / Relative handling ---
    if driverStatus.mode == "ABS" {
        moveToPos, destination = getAbsolutePosition(
            driverStatus.currentPosition,
            degreeToRotate,
            driverStatus.shortestPathEnabled,
        )
    } else {
        moveToPos, destination = getRelativePosition(
            driverStatus.currentPosition,
            degreeToRotate,
            driverStatus.destinationPosition,
        )
    }

    notifier.NotifyDestinationPosition(device.Name, float32(destination-driverStatus.workOffset))

    // ----------------------------------------------------------
    // ECS WAIT
    // ----------------------------------------------------------
    channels.WriteCommandExecInput("waiting_for_ecs", "")
    gotEcs := doECSCheck(device, destination)
    if gotEcs == 0 || gotEcs == 2 {
        return fmt.Errorf("failed to receive ECS, program stopped/reset event received")
    }
    channels.WriteCommandExecInput("ecs_done", "")

    // Refresh
    driverStatusAfterECS := getCurrentDriverStatus(device.Device.Name)

    // ----------------------------------------------------------
    // ABS FAST-PATH (NO MOVEMENT NEEDED)
    // ----------------------------------------------------------
    if driverStatusAfterECS.mode == "ABS" &&
        math.Abs(driverStatusAfterECS.currentPosition-destination) <= positionToleranceFastPath {

        recheck := getCurrentDriverStatus(device.Device.Name)

        if math.Abs(recheck.currentPosition-destination) <= positionToleranceFastPath {
            logger.Info("Already at target — sending finish immediately", "id:", uid)

            sendECSFinSignal(device)

            // ECS ZERO
            channels.WriteCommandExecInput("waiting_for_ecs", "")
            gotEcsZero := doECSCheckZero(device, destination)
            if gotEcsZero == 0 || gotEcsZero == 2 {
                return fmt.Errorf("failed to receive ECS zero")
            }
            channels.WriteCommandExecInput("ecs_done", "")

            doneDriverAction()
            channels.DestinationReached()
            
            return nil
        }
    }

    // ----------------------------------------------------------
    // SET DIRECTION
    // ----------------------------------------------------------
    setDirection(device, driverStatusAfterECS, moveToPos)
    notifyDriverStatus("destination_position", fmt.Sprintf("%f", destination), device)

    // ----------------------------------------------------------
    // COMPENSATION
    // ----------------------------------------------------------
    backlash := driverStatusAfterECS.backlash
    pitchErr := getPitchError(device.Name, destination)
    moveToWithComp := moveToPos + pitchErr - backlash

    clearTargetReached(device)

    // ----------------------------------------------------------
    // ROTATE
    // ----------------------------------------------------------
    err := doRotate(device, moveToWithComp)
    if err != nil {
        return err
    }

    // ----------------------------------------------------------
    // STRONG SAFETY BLOCK BEFORE FINISH SIGNAL
    // (replaces waitForEncoderChange + waitForTargetReached)
    // ----------------------------------------------------------
    currentPos := getCurrentDriverStatus(device.Device.Name).currentPosition
    errVal := math.Abs(currentPos - destination)

    if errVal > positionToleranceFinal {
        logger.Error(
            "FINISH BLOCKED — target NOT reached!",
            "target=", destination,
            "current=", currentPos,
            "error=", errVal,
        )
        return fmt.Errorf("finish blocked: target not reached")
    }

    // ----------------------------------------------------------
    // SEND FINISH
    // ----------------------------------------------------------
    sendECSFinSignal(device)

    // ----------------------------------------------------------
    // ECS ZERO
    // ----------------------------------------------------------
    channels.WriteCommandExecInput("waiting_for_ecs", "")
    gotEcsZero := doECSCheckZero(device, destination)
    if gotEcsZero == 0 || gotEcsZero == 2 {
        return fmt.Errorf("failed to receive ECS zero")
    }
    channels.WriteCommandExecInput("ecs_done", "")

    doneDriverAction()
    channels.DestinationReached()

    logger.Info("move to position completed", "driver", device.Name, "id", uid)
    return nil
}

// ----------------------------------------------------------
// 🪜 Step Mode
// ----------------------------------------------------------

func stepMode(masterDevice MasterDevice, valueInDegreeToAdd float64) error {
    logger.Debug("step mode moving to position: ", valueInDegreeToAdd)

    driverStatus := getCurrentDriverStatus(masterDevice.Device.Name)
    if driverStatus.potNotExceeded {
        logger.Error("pot/not exceeded, exiting from move command")
        channels.StepModeComplete()
        return errors.New("pot/not exceeded, exiting from move command")
    }

    err := freeRotate(masterDevice, valueInDegreeToAdd)
    channels.StepModeComplete()
    return err
}

// ----------------------------------------------------------
// 🔁 Direction Selection
// ----------------------------------------------------------

func setDirection(device MasterDevice, driverStatus driverCurrentStatus, degreeToRotate float64) {
    if !driverStatus.shortestPathEnabled {
        notifyDriverStatusWithWait("rotation_direction", "1", device)
        return
    }

    if degreeToRotate > 0 {
        notifyDriverStatusWithWait("rotation_direction", "1", device)
    } else {
        notifyDriverStatusWithWait("rotation_direction", "-1", device)
    }
}

// ----------------------------------------------------------
// 🔄 Position Sync Helpers
// ----------------------------------------------------------

func RefreshCurrentPosition() {
    driveName := "A"
    status := getCurrentDriverStatus(driveName)
    actual := ReadActualPositionFromDrive(driveName)
    status.currentPosition = actual
    status.destinationPosition = actual
    logger.Info("[SYNC] Updated current position to %.3f° from drive encoder for drive %s", actual, driveName)
}

func ReadActualPositionFromDrive(driveName string) float64 {
    status := getCurrentDriverStatus(driveName)
    return status.currentPosition
}
