package motordriver

import (
    channels "EtherCAT/channels"
    logger "EtherCAT/logger"
    "EtherCAT/settings"
    "time"
)

var stopECSCheckChan chan bool
var isECSCheckInProgress bool

func init() {
    isECSCheckInProgress = false
    stopECSCheckChan = make(chan bool)
}

func stopECSCheck() {
    if isECSCheckInProgress {
        stopECSCheckChan <- true
    }
    isECSCheckInProgress = false
}

// -------------------------------------------------------------------
// ECS “GO-HIGH” Phase — wait until ECS goes high (ready to move)
// -------------------------------------------------------------------
func doECSCheck(masterDevice MasterDevice, degree float64) int {
    envSettings := settings.GetDriverSettings(masterDevice.Name)
    if envSettings.ECS == 1 {
        logger.Debug("driver", masterDevice.Name, "waiting for ECS HIGH. rotate to", degree)
        ecsRec, _ := waitForECS(masterDevice)
        if ecsRec == 1 {
            logger.Debug("driver", masterDevice.Name, "received ECS HIGH")
        } else if ecsRec == 0 {
            logger.Error("driver", masterDevice.Name, "NOT received ECS HIGH")
            channels.SendAlarm("Not received ECS")
        } else {
            logger.Info("exiting ECS check due to stop/reset event")
        }
        return ecsRec
    }
    return 1
}

// -------------------------------------------------------------------
// ECS “GO-LOW” Phase — wait forever until ECS goes low again
// -------------------------------------------------------------------
func doECSCheckZero(masterDevice MasterDevice, degree float64) int {
    envSettings := settings.GetDriverSettings(masterDevice.Name)
    if envSettings.ECS == 1 {
        logger.Debug("driver", masterDevice.Name, "waiting for ECS LOW (zero). rotate to", degree)
		debugECSOperation(masterDevice)
        ecsRec, _ := waitForECSZero(masterDevice)
        if ecsRec == 1 {
            logger.Debug("driver", masterDevice.Name, "ECS went LOW (zero phase done)")
        } else if ecsRec == 0 {
            logger.Error("driver", masterDevice.Name, "ECS zero NOT received")
            channels.SendAlarm("ECS did not go LOW")
        } else {
            logger.Info("exiting ECS zero check as program stop/reset event received")
        }
        return ecsRec
    }
    return 1
}

// -------------------------------------------------------------------
// Wait for ECS HIGH (ready)
// -------------------------------------------------------------------
func waitForECS(masterDevice MasterDevice) (int, error) {
    operation, err := GetEtherCATOperation("ecs", masterDevice.Device.AddressConfigName)
    if err != nil {
        return 0, err
    }
    driver := GetMotorDriver()
    isECSCheckInProgress = true
    ecsStat, err := driver.receivedECS(masterDevice, operation, stopECSCheckChan), nil
    isECSCheckInProgress = false
    return ecsStat, err
}

// -------------------------------------------------------------------
// Helper: read ECS bit directly via EtherCAT
// (returns 1 = high, 0 = low)
// -------------------------------------------------------------------
func readECSInput(masterDevice MasterDevice) int {
    operation, err := GetEtherCATOperation("ecs", masterDevice.Device.AddressConfigName)
    if err != nil {
        logger.Error("readECSInput: failed to get ECS operation:", err)
        return 1 // assume high (safe default)
    }

    const ecsBitMask = 0x01 // 👈 adjust this to your actual ECS bit position

    for _, step := range operation.Steps {
        if step.Action == "read" {
            val, _ := SDOUpload2(masterDevice.Master, masterDevice.Position, step)
            //logger.Trace("ECS raw 0x4F25 value:", val)

            // Apply bit mask to check ECS bit only
            if val&ecsBitMask == 0 {
                // ECS bit low (OFF)
                return 0
            }
            return 1 // ECS bit high (ON)
        }
    }
    return 1
}

// -------------------------------------------------------------------
// Wait for ECS LOW (forever, no timeout)
// -------------------------------------------------------------------
func waitForECSZero(masterDevice MasterDevice) (int, error) {
    isECSCheckInProgress = true
    defer func() { isECSCheckInProgress = false }()

    logger.Info("Waiting indefinitely for ECS to go LOW...")

    for {
        val := readECSInput(masterDevice) // 1 = high, 0 = low

        if val == 0 {
            // Double-check for stability
            stable := true
            for i := 0; i < 5; i++ {
                time.Sleep(20 * time.Millisecond)
                if readECSInput(masterDevice) != 0 {
                    stable = false
                    break
                }
            }
            if stable {
                logger.Info("ECS signal is LOW – continuing execution")
                return 1, nil
            }
        }

        select {
        case <-stopECSCheckChan:
            logger.Warn("ECS zero wait interrupted by stop/reset")
            return 2, nil
        default:
        }

        time.Sleep(50 * time.Millisecond)
    }
}

// -------------------------------------------------------------------
// Send finish signal to controller after motion complete
// -------------------------------------------------------------------
func sendECSFinSignal(device MasterDevice) error {
    settings := settings.GetDriverSettings(device.Name)
    if settings.FinishSignal == 0 {
        return nil
    }
    operation, _ := GetEtherCATOperation("finsignal", device.Device.AddressConfigName)
    operationEnd, err := GetEtherCATOperation("finsignalend", device.Device.AddressConfigName)
    if err != nil {
        return err
    }

    notifyDriverStatusWithWait("fin_signal", "1", device)
    logger.Trace("start sending ecs fin signal ", device.Name)

    for _, step := range operation.Steps {
        if step.Action == "read" {
            SDOUpload2(device.Master, device.Position, step)
        } else {
            SDODownload(device.Master, device.Position, step)
        }
    }

    time.Sleep(time.Duration(settings.ECSFinTiming) * time.Millisecond)

    for _, step := range operationEnd.Steps {
        if step.Action == "read" {
            SDOUpload2(device.Master, device.Position, step)
        } else {
            SDODownload(device.Master, device.Position, step)
        }
    }

    notifyDriverStatusWithWait("fin_signal", "0", device)
    logger.Trace("finish sending ecs fin signal ", device.Name)
    return nil
}

// Debug: print details of the ECS EtherCAT operation mapping
// -------------------------------------------------------------------
// Debug: print details of the ECS EtherCAT operation mapping
// -------------------------------------------------------------------
func debugECSOperation(masterDevice MasterDevice) {
    op, err := GetEtherCATOperation("ecs", masterDevice.Device.AddressConfigName)
    if err != nil {
        logger.Error("debugECSOperation: failed to get ECS operation:", err)
        return
    }

    logger.Info("----- ECS Operation Mapping -----")
    logger.Info("Device:", masterDevice.Device.Name)
    logger.Info("Operation Name:", op.Name)
    logger.Info("Number of Steps:", len(op.Steps))
    for i, step := range op.Steps {
        // Generic dump for all known fields
        logger.Info(
            "Step", i,
            "| Action:", step.Action,
            "| DataType:", step.DataType,
            "| Value:", step.Value,
        )

        // Try to print optional fields safely using recover()
        func() {
            defer func() { _ = recover() }()
            logger.Info("   (extra fields) Step struct:", step)
        }()
    }
    logger.Info("--------------------------------")
}